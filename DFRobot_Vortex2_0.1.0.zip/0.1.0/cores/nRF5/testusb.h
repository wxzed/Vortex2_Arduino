
#ifndef _TESTUSB_
#define _TESTUSB_
#include "pca10056.h"

extern void runusb(void);


#endif /* _DELAY_ */
