#ifndef VORTEX2_GLOBAL_H__
#define VORTEX2_GLOBAL_H__


#define CDC_MAX_DATA_LEN        128
#define UART_MAX_DATA_LEN        128
#endif
