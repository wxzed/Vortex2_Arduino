/**
 * Copyright (c) 2017 - 2018, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */
 #ifndef GPIOTE_ENABLED
#define GPIOTE_ENABLED 1
#endif
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

extern "C"{
	#include "nrfx_clock.h"
	#include "nrfx_power.h"
	#include "nrfx_power_clock.h"
	#include "nrf_drv_clock.h"
	#include "nrf_drv_power.h"
	#include "testusb.h"
	#include "nrf.h"
#include "app_util_platform.h"
#include "nrf_drv_usbd.h"
#include "nrf_drv_clock.h"
#include "nrf_gpio.h"
#include "nrf_drv_power.h"

#include "app_timer.h"
#include "app_usbd.h"
#include "app_usbd_core.h"
#include "app_usbd_hid_generic.h"
#include "app_usbd_hid_mouse.h"
#include "app_usbd_hid_kbd.h"
#include "app_error.h"
#include "nrf_drv_gpiote.h"
#include "nrf_gpiote.h"
#include "FreeRTOS.h"
#include "task.h"
#include "bsp.h"
#include "nordic_common.h"
#include "compiler_abstraction.h"
//#include "nrfx_pwm.h"
}
#include "Arduino.h"

#define ARDUINO_STACK_SIZE 	512
#define TASK_DELAY        	200           

TaskHandle_t  arduino_task_handle;

static void arduino_task_function (void * pvParameter)
{
	UNUSED_PARAMETER(pvParameter);
	setup();
	while(true)
	{
		loop();
		if (serialEventRun) serialEventRun();
		vTaskDelay(1);
	}
}
int main( void ){
	ret_code_t ret;
	enable_power_handler();
	enable_hardfault();
    ret = nrf_drv_power_init(NULL);
    APP_ERROR_CHECK(ret);
    ret = nrf_drv_clock_init();
    APP_ERROR_CHECK(ret);
	//enable_pwm_handler();
	//bsp_board_init(BSP_INIT_LEDS);
	runusb();
	UNUSED_VARIABLE(xTaskCreate(arduino_task_function, "arduino", ARDUINO_STACK_SIZE, NULL, 2, &arduino_task_handle));
	SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    vTaskStartScheduler();
	for(;;)
	{
	}
}



