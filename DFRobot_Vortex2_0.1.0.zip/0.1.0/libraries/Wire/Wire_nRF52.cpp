/*
 * TWI/I2C library for nRF5x
 * Copyright (c) 2015 Arduino LLC. All rights reserved.
 * Copyright (c) 2016 Sandeep Mistry All right reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifdef NRF52

extern "C" {
#include <string.h>
}

#include <Arduino.h>
#include <wiring_private.h>

#include "Wire.h"
#include "nrf_drv_twi.h"
#include "nrfx_twim.h"
#include "nrfx_twi.h"
#include "pca10056.h"
static const nrf_drv_twi_t m_twi = { 0, { .twim = NRFX_TWIM_INSTANCE(0) }, true };
TwoWire::TwoWire(NRF_TWIM_Type * p_twim, NRF_TWIS_Type * p_twis, IRQn_Type IRQn, uint8_t pinSDA, uint8_t pinSCL)
{
  ret_code_t err_code;
  const nrf_drv_twi_config_t twi_config = {
       .scl                = pinSCL,
       .sda                = pinSDA,
       .frequency          = NRF_DRV_TWI_FREQ_100K,
       .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
       .clear_bus_init     = false
   };
   err_code = nrf_drv_twi_init(&m_twi, &twi_config, NULL, NULL);
   APP_ERROR_CHECK(err_code);
}

void TwoWire::begin(void) {/*Master*/
    nrf_drv_twi_enable(&m_twi);
}

void TwoWire::begin(uint8_t address) {
  //Slave mode
}

void TwoWire::setClock(uint32_t baudrate) {
}

void TwoWire::end() {
}

uint8_t TwoWire::requestFrom(uint8_t address, size_t size, bool stopBit)
{
    if(size > BUFFER_LENGTH) {
        size = BUFFER_LENGTH;
    }
    size_t read = (nrf_drv_twi_rx(&m_twi, address, rxBuffer, size) == 0)?size:0;
    rxIndex = 0;
    rxLength = read;
    return read;
}

uint8_t TwoWire::requestFrom(uint8_t address, size_t size)
{
  return requestFrom(address, size, true);
}

void TwoWire::beginTransmission(uint8_t address) {
    transmitting = 1;
    txAddress = address;
    txIndex = 0;
    txLength = 0;
}

uint8_t TwoWire::endTransmission(bool stopBit)
{
	uint8_t ret = nrf_drv_twi_rx(&m_twi, txAddress, txBuffer, txLength);
	txIndex = 0;
    txLength = 0;
    transmitting = 0;
	return ret;
}

uint8_t TwoWire::endTransmission()
{
  return endTransmission(true);
}

size_t TwoWire::write(uint8_t data)
{
	if(transmitting) {
        if(txLength >= BUFFER_LENGTH) {
            return 0;
        }
        txBuffer[txIndex] = data;
        ++txIndex;
        txLength = txIndex;
    }
  return 1 ;
}

size_t TwoWire::write(const uint8_t *data, size_t size)
{
  //Try to store all data
  for(size_t i = 0; i < size; ++i)
  {
    //Return the number of data stored, when the buffer is full (if write return 0)
    if(!write(data[i]))
      return i;
  }
  return size;
}

int TwoWire::available(void)
{
	int result = rxLength - rxIndex;
	return result;
}

int TwoWire::read(void)
{
	int value = -1;
    if(rxIndex < rxLength) {
        value = rxBuffer[rxIndex];
        ++rxIndex;
    }
    return value;
}

int TwoWire::peek(void)
{
    int value = -1;
    if(rxIndex < rxLength) {
        value = rxBuffer[rxIndex];
    }
    return value;
}

void TwoWire::flush(void)
{
  // Do nothing, use endTransmission(..) to force
  // data transfer.
}

void TwoWire::onReceive(void(*function)(int))
{
  onReceiveCallback = function;
}

void TwoWire::onRequest(void(*function)(void))
{
  onRequestCallback = function;
}

void TwoWire::onService(void)
{
	/*
  if (_p_twis->EVENTS_WRITE)
  {
    _p_twis->EVENTS_WRITE = 0x0UL;

    receiving = true;

    rxBuffer.clear();

    _p_twis->RXD.PTR = (uint32_t)rxBuffer._aucBuffer;
    _p_twis->RXD.MAXCNT = sizeof(rxBuffer._aucBuffer);

    _p_twis->TASKS_PREPARERX = 0x1UL;
  }

  if (_p_twis->EVENTS_READ)
  {
    _p_twis->EVENTS_READ = 0x0UL;

    receiving = false;
    transmissionBegun = true;

    txBuffer.clear();

    if (onRequestCallback)
    {
      onRequestCallback();
    }

    transmissionBegun = false;

    _p_twis->TXD.PTR = (uint32_t)txBuffer._aucBuffer;
    _p_twis->TXD.MAXCNT = txBuffer.available();

    _p_twis->TASKS_PREPARETX = 0x1UL;
  }

  if (_p_twis->EVENTS_STOPPED)
  {
    _p_twis->EVENTS_STOPPED = 0x0UL;

    if (receiving)
    {
      int rxAmount = _p_twis->RXD.AMOUNT;

      rxBuffer._iHead = rxAmount;

      if (onReceiveCallback)
      {
        onReceiveCallback(rxAmount);
      }
    }
  }

  if (_p_twis->EVENTS_ERROR)
  {
    _p_twis->EVENTS_ERROR = 0x0UL;

    uint32_t error = _p_twis->ERRORSRC;
    _p_twis->ERRORSRC = error;

    _p_twis->TASKS_STOP = 0x1UL;
  }*/
}

//TwoWire Wire(NRF_TWIM0, NRF_TWIS0, SPIM0_SPIS0_TWIM0_TWIS0_SPI0_TWI0_IRQn, PIN_WIRE_SDA, PIN_WIRE_SCL);
TwoWire Wire(NRF_TWIM0, NRF_TWIS0, SPIM0_SPIS0_TWIM0_TWIS0_SPI0_TWI0_IRQn, ARDUINO_SDA_PIN, ARDUINO_SCL_PIN);
#if WIRE_INTERFACES_COUNT > 0
extern "C"
{
	/*
  void SPIM1_SPIS1_TWIM1_TWIS1_SPI1_TWI1_IRQHandler(void)
  {
    Wire.onService();
  }*/
}
#endif

#endif
